﻿DLTB.RIP v1.2.0 - trainer & visual mod for Dying Light: The Beast
=================================================================

[ENGLISH]

WHAT'S NEW IN 1.2.0
- Map tab: interactive world map with your own markers (pins in the world, teleport), explored trail,
  collectibles and quest items found around you, game locations (safe zones, convoys, hives, dark zones,
  shops...), your own locations, filters and search. The map backdrop is drawn from the game's own data.
- 7 menu languages: English, Russian, Polish, Spanish, French, German, Simplified Chinese
  (Interface > Menu Theme > Language).
- New menu design "Cyber".
- Wallhack: separate ESP for Zombies and Humans, skeleton on the real game bones, radar.
- Pet (Clawd), Session Stats, Bind List, Media Player, draggable HUD, parkour trail, New Year theme.
- Item Extravaganza 1.1.3 and NIGHTVEIN r195 (game build 26402545). Instant Search / Pickup now also
  works on containers, wardrobes, lying items and collectibles.
- Full list: see the changelog on the Nexus Mods page.

REQUIREMENTS
- Dying Light: The Beast (Steam, Windows 10/11 x64).
- Nothing else to install: no game-folder files, no Visual C++ redistributable.

INSTALL
- Extract the whole archive into its own folder (for example C:\Games\DLTB.RIP).
  Keep DLTB.RIP.exe, "Start DLTB.RIP.bat" and the "items", "nightvein" and "map" folders together.
- Avoid Program Files (if the folder is read-only, settings go to %LOCALAPPDATA%\DLTB.RIP).
- Updating from an older version: replace the old files with the new ones. Your "configs" folder keeps working.
  If the game is running with an older DLTB.RIP runtime loaded, restart the game once.

HOW TO START - choose one way
1) From the desktop: run "Start DLTB.RIP.bat".
   It starts the game through Steam (if it is not running yet), waits for it,
   then starts the trainer.
2) While you are already playing: run DLTB.RIP.exe (Alt+Tab or a shortcut).
   No restart needed - it attaches to the running game.

Windows asks for administrator rights - this is required to work with the game's memory.
In game press INSERT to open/close the menu. END unloads the trainer (changeable in Configs).
Running DLTB.RIP.exe again while it is open restarts it cleanly.
When you quit the game, the trainer closes by itself and removes all its changes.

MAP TAB
- Left panel: found / total, search, categories (click to show or hide), your markers.
  Mouse wheel zooms, drag with the left button, right click opens a menu (Teleport Here, Add Marker, Add Location...).
- The backdrop is the file map\worldmap.dlmap. If it is missing the map still works, without the backdrop.
- Collectibles appear as you play: the game layer scans around you and reads the "taken" state from the game.
- Your points are saved in configs\map\.

ITEMS TAB (Item Extravaganza)
- Items > Catalog uses Item Extravaganza's engine (included in the "items" folder
  with its author's permission). Press "Load Item Extravaganza" once per game session.
- Back up your save first. Single-player only. Changes can be autosaved.
- Do not run the original ItemExtravaganza.exe in the same game session.

NIGHTVEIN FEATURES
- Instant Reload, Instant Search / Pickup, Loot My Kills, vehicle spawning/tuning, the
  native third-person camera and the collectible scan for the map use NIGHTVEIN's game layer
  ("nightvein" folder, included with its author's permission). It loads into the game by itself.
- Do not also load NIGHTVEIN itself in the same game session.

NOTES
- Single-player use only. Use at your own risk; back up your saves.
- Settings are saved in the "configs" folder next to DLTB.RIP.exe (Configs tab).
- Antivirus: the trainer edits game memory and loads a DLL into the game, which some
  antivirus programs flag. Download only from the official Nexus Mods page.
- A game update can disable some features until the mod is updated.

CREDITS
- Item Extravaganza by Atom0420 - https://www.nexusmods.com/dyinglightthebeast/mods/1026. Included with permission;
  see items\LICENSE.txt, items\COPYRIGHT.txt, items\RIGHTS-AND-ATTRIBUTION.md.
- NIGHTVEIN by Atom (Atom0420) - https://www.nexusmods.com/dyinglightthebeast/mods/1069 - instant reload,
  instant search/pickup, loot my kills, vehicles, third-person camera and map scan. Included with permission;
  see nightvein\LICENSE.txt and the other licenses there.
- Dear ImGui by Omar Cornut (MIT).
- Manrope font and Font Awesome 5 Free icons (SIL Open Font License 1.1) - see the "licenses" folder.
- "Rust Headshot" hit sound is from the game Rust (Facepunch Studios); all rights belong to its owner.
- Map data (terrain, roads, locations, item names) is read from Dying Light: The Beast files; all rights belong to Techland.
- Not affiliated with Techland, Valve or Nexus Mods.


[РУССКИЙ]

ЧТО НОВОГО В 1.2.0
- Вкладка Map: интерактивная карта мира со своими метками (булавки в мире, телепорт), следом «исследовано»,
  коллекционными и квестовыми предметами рядом, локациями игры (безопасные зоны, конвои, гнёзда, тёмные зоны,
  магазины...), своими локациями, фильтрами и поиском. Подложка карты рисуется из данных самой игры.
- 7 языков меню: English, Русский, Polski, Español, Français, Deutsch, 简体中文
  (Interface > Menu Theme > Language).
- Новый дизайн меню «Cyber».
- Wallhack: отдельные ESP для зомби и людей, скелет по настоящим костям игры, радар.
- Pet (Clawd), Session Stats, Bind List, Media Player, перетаскиваемый HUD, след паркура, новогодняя тема.
- Item Extravaganza 1.1.3 и NIGHTVEIN r195 (сборка игры 26402545). Instant Search / Pickup теперь работает
  и на контейнерах, шкафах, лежащих предметах и коллекционных.
- Полный список - в changelog на странице Nexus Mods.

ТРЕБОВАНИЯ
- Dying Light: The Beast (Steam, Windows 10/11 x64).
- Больше ничего ставить не нужно: никаких файлов в папку игры, никакого Visual C++ Redistributable.

УСТАНОВКА
- Распакуйте архив целиком в отдельную папку (например, C:\Games\DLTB.RIP).
  DLTB.RIP.exe, "Start DLTB.RIP.bat" и папки "items", "nightvein" и "map" должны лежать вместе.
- Не кладите в Program Files (если папка только для чтения, настройки уйдут в %LOCALAPPDATA%\DLTB.RIP).
- Обновление со старой версии: замените старые файлы новыми. Папка "configs" продолжит работать.
  Если игра запущена со старым рантаймом DLTB.RIP, один раз перезапустите игру.

КАК ЗАПУСТИТЬ - один из двух способов
1) С рабочего стола: запустите "Start DLTB.RIP.bat".
   Он запустит игру через Steam (если она ещё не запущена), дождётся её и запустит трейнер.
2) Прямо во время игры: запустите DLTB.RIP.exe (Alt+Tab или ярлык).
   Игру перезапускать не нужно - трейнер подключится к запущенной игре.

Windows попросит права администратора - они нужны для работы с памятью игры.
В игре INSERT - открыть/закрыть меню. END - выгрузить трейнер (меняется в Configs).
Повторный запуск DLTB.RIP.exe корректно перезапускает трейнер.
Когда вы выходите из игры, трейнер закрывается сам и снимает все свои изменения.

ВКЛАДКА MAP
- Слева панель: найдено / всего, поиск, категории (клик - показать или скрыть), ваши метки.
  Колесо мыши - масштаб, левая кнопка - перетаскивание, правая - меню (Teleport Here, Add Marker, Add Location...).
- Подложка - файл map\worldmap.dlmap. Если его нет, карта работает без подложки.
- Коллекционные появляются по ходу игры: игровой слой сканирует окрестности и берёт из игры состояние «собран».
- Ваши точки сохраняются в configs\map\.

ВКЛАДКА ITEMS (Item Extravaganza)
- Items > Catalog работает на движке Item Extravaganza (лежит в папке "items",
  включён с разрешения автора). Нажмите "Load Item Extravaganza" один раз за сеанс игры.
- Сначала сделайте резервную копию сохранения. Только одиночная игра. Изменения могут автосохраниться.
- Не запускайте оригинальный ItemExtravaganza.exe в том же сеансе игры.

ФУНКЦИИ NIGHTVEIN
- Instant Reload, Instant Search / Pickup, Loot My Kills, спавн и настройка машин, родное
  третье лицо и поиск коллекционных для карты работают на игровом слое NIGHTVEIN (папка "nightvein",
  включён с разрешения автора). Он загружается в игру сам.
- Не загружайте сам NIGHTVEIN в том же сеансе игры.

ВАЖНО
- Только для одиночной игры. На свой риск; делайте копии сохранений.
- Настройки хранятся в папке "configs" рядом с DLTB.RIP.exe (вкладка Configs).
- Антивирус: трейнер меняет память игры и загружает в неё DLL - некоторые антивирусы
  на это реагируют. Скачивайте только с официальной страницы на Nexus Mods.
- Обновление игры может временно отключить часть функций до обновления мода.

БЛАГОДАРНОСТИ
- Item Extravaganza - Atom0420 - https://www.nexusmods.com/dyinglightthebeast/mods/1026. Включён с разрешения автора;
  см. items\LICENSE.txt, items\COPYRIGHT.txt, items\RIGHTS-AND-ATTRIBUTION.md.
- NIGHTVEIN - Atom (Atom0420) - https://www.nexusmods.com/dyinglightthebeast/mods/1069: instant reload,
  instant search/pickup, loot my kills, машины, третье лицо и поиск для карты. Включён с разрешения автора;
  см. nightvein\LICENSE.txt и другие лицензии там.
- Dear ImGui - Omar Cornut (MIT).
- Шрифт Manrope и иконки Font Awesome 5 Free (SIL Open Font License 1.1) - см. папку "licenses".
- Звук попадания "Rust Headshot" - из игры Rust (Facepunch Studios); все права у правообладателя.
- Данные карты (рельеф, дороги, локации, названия предметов) читаются из файлов Dying Light: The Beast; все права у Techland.
- Мод не связан с Techland, Valve или Nexus Mods.
